# grupo_13_ferreteria
Nos inspiramos en paginas como Sodimac, Easy, Mercado Libre, Amazon, entre otras y familiares y conocidos de los integrantes del grupo, todo esto con el fin de crear un ecommerce de una ferreteria. Nos parecio una buena idea ya que teniamos experiencia en el area de las herramientas y articulos del hogar
les dejamos el link de figma donde hicimos los wireframes de desktop, mobile y tablet.
https://www.figma.com/team_invite/redeem/5MkZvjuVW3wrs5vtWTTnVt. 
Nuestro Ecommerce "El Cosito" esta destinado a ventas al por mayor o menor de objetos de ferreteria.